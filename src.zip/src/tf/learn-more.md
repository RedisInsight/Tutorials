### Documentation

* [Triggers and Functions home](https://redis.io/docs/interact/programmability/triggers-and-functions/?utm_source=redisinsight&utm_medium=main&utm_campaign=tutorials)

### Social

* [Triggers and Functions on GitHub](https://github.com/RedisGears/RedisGears)
* [Triggers and Functions on Discord](https://discord.com/channels/697882427875393627/1187465067793481758)

### Blogs

* [Expanding the Database Triggers Features in Redis](https://redis.com/blog/database-trigger-features/?utm_source=redisinsight&utm_medium=main&utm_campaign=tutorials)
* [Triggers and Functions Preview](https://redis.com/blog/introducing-triggers-and-functions/?utm_source=redisinsight&utm_medium=main&utm_campaign=tutorials)

### Tutorials

* [Examples](https://redis.io/docs/interact/programmability/triggers-and-functions/examples/?utm_source=redisinsight&utm_medium=main&utm_campaign=tutorials)
